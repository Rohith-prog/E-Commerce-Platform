
# E-Commerce Platform (Spring Boot, JWT, MVC, JPA)

A modular **e-commerce REST API** built with **Spring Boot**, **JWT authentication**, and **MVC architecture**. 
Includes **H2 in-memory DB** for instant run, optional MySQL profile, and **JUnit/Mockito tests** with JaCoCo coverage.

## ✨ Highlights
- **JWT auth**: `/api/auth/register`, `/api/auth/login`
- **Products**: CRUD (admin) + browse (public)
- **Orders**: place + view my orders
- **Performance**: HikariCP pooling, query indexes, batch settings
- **Quality**: Layered architecture (controller → service → repo), validation, tests

## 🔧 Tech
Java 11 • Spring Boot 2.7 • Spring Security • Spring Data JPA • H2/MySQL • JUnit 5 • Mockito • JaCoCo

---

## 🚀 Quick Start (H2 - no setup)
```bash
# from project root
./mvnw spring-boot:run   # or: mvn spring-boot:run
```
Open: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:ecom`)

### Sample requests
```bash
# Register
curl -X POST http://localhost:8080/api/auth/register -H "Content-Type: application/json" -d '{"email":"user@example.com","password":"Pass@123","name":"User"}'

# Login -> receives JWT token
curl -X POST http://localhost:8080/api/auth/login -H "Content-Type: application/json" -d '{"email":"user@example.com","password":"Pass@123"}'

# Get products (public)
curl http://localhost:8080/api/products

# Create product (admin) - use admin token
curl -X POST http://localhost:8080/api/products -H "Authorization: Bearer <ADMIN_JWT>" -H "Content-Type: application/json" -d '{"name":"Laptop","price":79999,"stock":15}'
```

---

## 🛢️ Switch to MySQL
1. Create DB: `CREATE DATABASE ecommerce CHARACTER SET utf8mb4;`
2. Copy `src/main/resources/application-mysql.properties.sample` → `src/main/resources/application-mysql.properties` and edit creds.
3. Run with profile:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

---

## 📈 Tests & Coverage
```bash
mvn clean test
# report: target/site/jacoco/index.html
```
Add more tests to exceed **85% coverage** (sample tests included).

---

## 🏗️ Architecture
```
com.rohithk.ecommerce
 ├─ config/         # security, JWT, filters
 ├─ controller/     # REST controllers
 ├─ dto/            # request/response DTOs
 ├─ model/          # JPA entities
 ├─ repository/     # Spring Data JPA repos
 ├─ service/        # business logic
 └─ util/           # helpers, constants
```

---

## 🔐 Default Admin
On startup, a default admin is created:
- email: `admin@local`
- password: `Admin@123`

Change this in `DataLoader.java` after first run.

---

## ☁️ Deploy / Docker (optional)
- Add `spring-boot-starter-actuator` for health endpoints.
- Create Dockerfile & use Jib or Boot build-image.

---

## 📤 Upload to GitHub (step-by-step)
1. **Create repo on GitHub** (no README/.gitignore yet).  
2. **Local init**
```bash
git init
git add .
git commit -m "feat: e-commerce platform with JWT, MVC, tests"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
3. **Add CI (optional)**: GitHub Actions workflow is included at `.github/workflows/maven.yml`.

---

## ⚠️ Notes
- **JWT secret** is stored in `application.properties` for demo—use an env var in production.
- Passwords hashed with **BCrypt**.
- H2 is for local; use MySQL/Postgres in production.
