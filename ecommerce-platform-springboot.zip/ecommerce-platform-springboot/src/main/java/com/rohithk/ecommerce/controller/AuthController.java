
package com.rohithk.ecommerce.controller;

import com.rohithk.ecommerce.config.JwtTokenProvider;
import com.rohithk.ecommerce.dto.AuthResponse;
import com.rohithk.ecommerce.dto.LoginRequest;
import com.rohithk.ecommerce.dto.RegisterRequest;
import com.rohithk.ecommerce.model.User;
import com.rohithk.ecommerce.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Set;

@RestController
@RequestMapping("/api/auth")
@Validated
public class AuthController {

    private final UserService userService;
    private final AuthenticationManager authManager;
    private final JwtTokenProvider jwt;

    public AuthController(UserService userService, AuthenticationManager authManager, JwtTokenProvider jwt) {
        this.userService = userService;
        this.authManager = authManager;
        this.jwt = jwt;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest req) {
        User u = userService.register(req.getName(), req.getEmail(), req.getPassword(), Set.of("USER"));
        String token = jwt.createToken(u.getEmail());
        return ResponseEntity.ok(new AuthResponse(token));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest req) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        SecurityContextHolder.getContext().setAuthentication(auth);
        String token = jwt.createToken(req.getEmail());
        return ResponseEntity.ok(new AuthResponse(token));
    }
}
