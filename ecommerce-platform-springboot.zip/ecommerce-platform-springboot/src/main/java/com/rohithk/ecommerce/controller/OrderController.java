
package com.rohithk.ecommerce.controller;

import com.rohithk.ecommerce.dto.OrderRequest;
import com.rohithk.ecommerce.model.Order;
import com.rohithk.ecommerce.model.User;
import com.rohithk.ecommerce.service.OrderService;
import com.rohithk.ecommerce.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
@Validated
public class OrderController {
    private final OrderService orders;
    private final UserService users;
    public OrderController(OrderService orders, UserService users) { this.orders = orders; this.users = users; }

    @PostMapping
    public ResponseEntity<Order> place(@Valid @RequestBody OrderRequest req, Authentication auth) {
        User u = users.findByEmail(auth.getName()).orElseThrow();
        return ResponseEntity.ok(orders.placeOrder(u, req));
    }

    @GetMapping("/me")
    public List<Order> myOrders(Authentication auth) {
        User u = users.findByEmail(auth.getName()).orElseThrow();
        return orders.myOrders(u);
    }
}
