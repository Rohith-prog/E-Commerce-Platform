
package com.rohithk.ecommerce.service;

import com.rohithk.ecommerce.model.Order;
import com.rohithk.ecommerce.model.User;
import com.rohithk.ecommerce.dto.OrderRequest;
import java.util.List;

public interface OrderService {
    Order placeOrder(User user, OrderRequest request);
    List<Order> myOrders(User user);
}
