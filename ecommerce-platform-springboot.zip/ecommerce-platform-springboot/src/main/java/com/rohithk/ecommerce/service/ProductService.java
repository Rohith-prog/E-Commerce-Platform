
package com.rohithk.ecommerce.service;

import com.rohithk.ecommerce.model.Product;
import java.util.List;
import java.util.Optional;

public interface ProductService {
    Product create(Product p);
    List<Product> list();
    Optional<Product> get(Long id);
    Product update(Long id, Product p);
    void delete(Long id);
}
