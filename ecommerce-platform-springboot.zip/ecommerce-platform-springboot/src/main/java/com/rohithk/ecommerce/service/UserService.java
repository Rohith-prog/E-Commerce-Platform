
package com.rohithk.ecommerce.service;

import com.rohithk.ecommerce.model.User;

import java.util.Optional;
import java.util.Set;

public interface UserService {
    User register(String name, String email, String rawPassword, Set<String> roles);
    Optional<User> findByEmail(String email);
}
