
package com.rohithk.ecommerce.service.impl;

import com.rohithk.ecommerce.dto.OrderItemRequest;
import com.rohithk.ecommerce.dto.OrderRequest;
import com.rohithk.ecommerce.model.*;
import com.rohithk.ecommerce.repository.OrderRepository;
import com.rohithk.ecommerce.repository.ProductRepository;
import com.rohithk.ecommerce.service.OrderService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orders;
    private final ProductRepository products;
    public OrderServiceImpl(OrderRepository orders, ProductRepository products) {
        this.orders = orders; this.products = products;
    }

    @Override @Transactional
    public Order placeOrder(User user, OrderRequest request) {
        Order order = new Order(user);
        for (OrderItemRequest itemReq : request.getItems()) {
            Product p = products.findById(itemReq.getProductId())
                    .orElseThrow(() -> new IllegalArgumentException("Product not found: " + itemReq.getProductId()));
            if (p.getStock() < itemReq.getQuantity()) {
                throw new IllegalArgumentException("Insufficient stock for product: " + p.getName());
            }
            p.setStock(p.getStock() - itemReq.getQuantity());
            OrderItem item = new OrderItem(order, p, itemReq.getQuantity());
            order.getItems().add(item);
        }
        return orders.save(order);
    }

    @Override @Transactional(readOnly = true)
    public List<Order> myOrders(User user) {
        return orders.findByUser(user);
    }
}
