
package com.rohithk.ecommerce.service.impl;

import com.rohithk.ecommerce.model.Product;
import com.rohithk.ecommerce.repository.ProductRepository;
import com.rohithk.ecommerce.service.ProductService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository repo;
    public ProductServiceImpl(ProductRepository repo) { this.repo = repo; }

    @Override @Transactional
    public Product create(Product p) { return repo.save(p); }

    @Override @Transactional(readOnly = true)
    public List<Product> list() { return repo.findAll(); }

    @Override @Transactional(readOnly = true)
    public Optional<Product> get(Long id) { return repo.findById(id); }

    @Override @Transactional
    public Product update(Long id, Product p) {
        return repo.findById(id).map(existing -> {
            existing.setName(p.getName());
            existing.setDescription(p.getDescription());
            existing.setPrice(p.getPrice());
            existing.setStock(p.getStock());
            return repo.save(existing);
        }).orElseThrow(() -> new IllegalArgumentException("Product not found"));
    }

    @Override @Transactional
    public void delete(Long id) { repo.deleteById(id); }
}
