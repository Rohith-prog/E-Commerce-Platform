
package com.rohithk.ecommerce.service.impl;

import com.rohithk.ecommerce.model.User;
import com.rohithk.ecommerce.repository.UserRepository;
import com.rohithk.ecommerce.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository repo;
    private final PasswordEncoder encoder;

    public UserServiceImpl(UserRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    @Override @Transactional
    public User register(String name, String email, String rawPassword, Set<String> roles) {
        if (repo.existsByEmail(email)) throw new IllegalArgumentException("Email already registered");
        User u = new User(name, email.toLowerCase(), encoder.encode(rawPassword), roles);
        return repo.save(u);
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return repo.findByEmail(email.toLowerCase());
    }
}
