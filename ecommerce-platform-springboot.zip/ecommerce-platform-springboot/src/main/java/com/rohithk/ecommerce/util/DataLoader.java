
package com.rohithk.ecommerce.util;

import com.rohithk.ecommerce.model.Product;
import com.rohithk.ecommerce.service.ProductService;
import com.rohithk.ecommerce.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Set;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner init(UserService users, ProductService products) {
        return args -> {
            try {
                users.register("Admin", "admin@local", "Admin@123", Set.of("ADMIN"));
            } catch (Exception ignored) {}
            if (products.list().isEmpty()) {
                products.create(new Product("Laptop", "14-inch, 16GB RAM", 7999900L, 25));
                products.create(new Product("Headphones", "Noise cancelling", 999900L, 100));
                products.create(new Product("Keyboard", "Mechanical", 349900L, 50));
            }
        };
    }
}
