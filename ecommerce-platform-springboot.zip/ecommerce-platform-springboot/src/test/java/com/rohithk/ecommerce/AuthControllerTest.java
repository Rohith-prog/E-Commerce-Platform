
package com.rohithk.ecommerce;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rohithk.ecommerce.config.JwtTokenProvider;
import com.rohithk.ecommerce.dto.LoginRequest;
import com.rohithk.ecommerce.dto.RegisterRequest;
import com.rohithk.ecommerce.model.User;
import com.rohithk.ecommerce.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;
import java.util.Set;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(controllers = com.rohithk.ecommerce.controller.AuthController.class)
class AuthControllerTest {

    @Autowired private MockMvc mvc;
    @Autowired private ObjectMapper mapper;

    @MockBean private UserService userService;
    @MockBean private AuthenticationManager authManager;
    @MockBean private JwtTokenProvider jwtProvider;
    @MockBean private org.springframework.security.core.userdetails.UserDetailsService uds;
    @MockBean private com.rohithk.ecommerce.config.JwtAuthenticationFilter filter;

    @Test
    void register_returnsToken() throws Exception {
        RegisterRequest req = new RegisterRequest();
        req.setName("User"); req.setEmail("user@test.com"); req.setPassword("Secret1!");
        Mockito.when(userService.register(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new User("User", "user@test.com", "hash", Set.of("USER")));
        Mockito.when(jwtProvider.createToken(Mockito.any())).thenReturn("fake.jwt");

        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("fake.jwt"));
    }

    @Test
    void login_returnsToken() throws Exception {
        LoginRequest req = new LoginRequest();
        req.setEmail("user@test.com"); req.setPassword("Secret1!");
        Mockito.when(jwtProvider.createToken(Mockito.any())).thenReturn("fake.jwt");
        Mockito.when(authManager.authenticate(Mockito.any(Authentication.class))).thenReturn(Mockito.mock(Authentication.class));

        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("fake.jwt"));
    }
}
