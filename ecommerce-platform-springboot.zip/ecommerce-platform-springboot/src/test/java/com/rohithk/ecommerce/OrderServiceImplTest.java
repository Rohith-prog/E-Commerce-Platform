
package com.rohithk.ecommerce;

import com.rohithk.ecommerce.dto.OrderItemRequest;
import com.rohithk.ecommerce.dto.OrderRequest;
import com.rohithk.ecommerce.model.Order;
import com.rohithk.ecommerce.model.Product;
import com.rohithk.ecommerce.model.User;
import com.rohithk.ecommerce.repository.OrderRepository;
import com.rohithk.ecommerce.repository.ProductRepository;
import com.rohithk.ecommerce.service.impl.OrderServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;
import java.util.Optional;
import java.util.Set;

class OrderServiceImplTest {

    private OrderRepository orderRepo;
    private ProductRepository productRepo;
    private OrderServiceImpl service;
    private User user;

    @BeforeEach
    void setup() {
        orderRepo = Mockito.mock(OrderRepository.class);
        productRepo = Mockito.mock(ProductRepository.class);
        service = new OrderServiceImpl(orderRepo, productRepo);
        user = new User("User","u@t.com","hash", Set.of("USER"));
    }

    @Test
    void placeOrder_reducesStockAndSaves() {
        Product p = new Product("Item","", 100L, 10);
        Mockito.when(productRepo.findById(1L)).thenReturn(Optional.of(p));
        Mockito.when(orderRepo.save(Mockito.any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

        OrderItemRequest item = new OrderItemRequest();
        item.setProductId(1L); item.setQuantity(3);
        OrderRequest req = new OrderRequest();
        req.setItems(List.of(item));

        Order saved = service.placeOrder(user, req);
        Assertions.assertEquals(7, p.getStock().intValue());
        Assertions.assertEquals(1, saved.getItems().size());
    }
}
