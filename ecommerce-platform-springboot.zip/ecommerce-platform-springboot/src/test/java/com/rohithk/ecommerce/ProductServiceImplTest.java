
package com.rohithk.ecommerce;

import com.rohithk.ecommerce.model.Product;
import com.rohithk.ecommerce.repository.ProductRepository;
import com.rohithk.ecommerce.service.impl.ProductServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class ProductServiceImplTest {
    @Test
    void create_savesProduct() {
        ProductRepository repo = Mockito.mock(ProductRepository.class);
        ProductServiceImpl service = new ProductServiceImpl(repo);
        Product p = new Product("Phone","", 100L, 5);
        service.create(p);
        ArgumentCaptor<Product> captor = ArgumentCaptor.forClass(Product.class);
        Mockito.verify(repo).save(captor.capture());
        Assertions.assertEquals("Phone", captor.getValue().getName());
    }
}
